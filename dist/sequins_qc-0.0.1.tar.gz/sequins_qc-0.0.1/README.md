# Sequins_QC
cDNA/dRNA transcriptomics Inner sequence Quality Control with Sequins
